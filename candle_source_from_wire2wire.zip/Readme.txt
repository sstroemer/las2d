Supporting file for the 5 channel LED candle (http://www.wire2wire.org/LED_candle/LED_candle.html)

candle_sim00-00.asm => assembly source code for the PIC12F508
candle_sim00-00.hex => intel hex binary for programming the PIC12F508
led_candle_V_bot.png => picture of bottom layer for reference of the value edition
led_candle_V_logic.png => picture of card logic of the value edition
led_candle_V_top.png => picture of top layer + reference designation for reference of the value edition
led_candle_value0z.brd => Eagle Cad 6.5.0 board file of the value edition
led_candle_value0z.sch => Eagle Cad 6.5.0 schematics of the value edition
led_candle0z.brd => Eagle Cad 6.5.0 board file
led_candle0z.sch => Eagle Cad 6.5.0 schematics 
led_candle0z_V-bom.txt => card Bill of Material of the value edition
led_candle0z-bom.txt => card Bill of Material
led_candle-bot.png => picture of bottom layer for reference 
led_candle-logic.png => picture of card logic
led_candle-bot.png => picture of top layer + reference designation for reference 
Readme.txt => this file 

./gerber_premium/led_candle0z.bot => bottom gerber data in gerber_RS274X format
./gerber_premium/led_candle0z.bsk => bottom silk screen data in gerber_RS274X format
./gerber_premium/led_candle0z.exc => drill data in excellon format
./gerber_premium/led_candle0z.ipc => IPC data
./gerber_premium/led_candle0z.smb => bottom solder mask data in gerber_RS274X format
./gerber_premium/led_candle0z.smt => top solder mask data in gerber_RS274X format
./gerber_premium/led_candle0z.top => top gerber data in gerber_RS274X format
./gerber_premium/led_candle0z.tsk => top silk screen gerber data in gerber_RS274X format

./gerber_value/led_candle_value0z.bot => bottom gerber data in gerber_RS274X format
./gerber_value/led_candle_value0z.bsk => bottom silk screen data in gerber_RS274X format
./gerber_value/led_candle_value0z.exc => drill data in excellon format
./gerber_value/led_candle_value0z.ipc => IPC data
./gerber_value/led_candle_value0z.smb => bottom solder mask data in gerber_RS274X format
./gerber_value/led_candle_value0z.smt => top solder mask data in gerber_RS274X format
./gerber_value/led_candle_value0z.top => top gerber data in gerber_RS274X format
./gerber_value/led_candle_value0z.tsk => top silk screen gerber data in gerber_RS274X format
